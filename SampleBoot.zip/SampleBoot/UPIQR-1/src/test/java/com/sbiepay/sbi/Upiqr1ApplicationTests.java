package com.sbiepay.sbi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Upiqr1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
