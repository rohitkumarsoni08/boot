package com.sbiepay.sbi.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sbiepay.sbi.model.Sales;

@Repository
public interface SalesRepository extends JpaRepository<Sales, Long>{

}